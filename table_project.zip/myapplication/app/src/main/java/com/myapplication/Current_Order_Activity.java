package com.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Current_Order_Activity extends AppCompatActivity {
    OrderModel orderModel;
    TextView tv_time;
    DatabaseReference Order_Ref;
    CountDownTimer timer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_order);
        Order_Ref= FirebaseDatabase.getInstance().getReference("Order").child(FirebaseAuth.getInstance().getCurrentUser().getUid());

        orderModel= (OrderModel) getIntent().getSerializableExtra("model");
        tv_time=findViewById(R.id.tv_time);
        tv_time.setText(orderModel.getTime());
        final SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss"); //hours and minutes, 24hr clock
        Log.e("eeee",format.format(new Date()));
        try {
            Date date1=format.parse(orderModel.getTime());
            Date date2=format.parse(format.format(new Date()));
            long l=date1.getTime();
            date1.setTime(l+(30*60*1000));
            long l1=date1.getTime();
            long l2=date2.getTime();
            if (l2<l1){
                long l3=l1-l2;
                timer=new CountDownTimer(l3,1000) {
                    @Override
                    public void onTick(long l) {
                        tv_time.setText(""+l);
                        long millis = l;
                        String hms = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(millis),
                                TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)),
                                TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
                        System.out.println(hms);
                        tv_time.setText(hms);
                    }

                    @Override
                    public void onFinish() {

                    }
                }.start();
            }
            else {
                SHow_Dialog();
            }
            try {
                String _24HourTime = "22:15";
                SimpleDateFormat _24HourSDF = new SimpleDateFormat("HH:mm");
                SimpleDateFormat _12HourSDF = new SimpleDateFormat("hh:mm a");
                Date _24HourDt = _24HourSDF.parse(_24HourTime);
                Log.e("eeee",_24HourDt.toString());
                Log.e("eeee",_12HourSDF.format(_24HourDt));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        LocalTime time = LocalTime.of(Integer.parseInt(orderModel.getTime().split(":")[0]), Integer.parseInt(orderModel.getTime().split(":")[1]));
        time.plusMinutes(30);
        Log.e("eeee",time.toString());
    }

    private void SHow_Dialog() {
        AlertDialog.Builder builder=new AlertDialog.Builder(Current_Order_Activity.this);
        builder.setMessage("Order Complete Or Cancel, Because Time Finish.");
        builder.setCancelable(false);
        builder.setPositiveButton("Complete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                String key= orderModel.getKey();
                orderModel.setStatus("Complete");
                Order_Ref.child(key).setValue(orderModel);
                Toast.makeText(Current_Order_Activity.this, "Complete Successfully", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Current_Order_Activity.this,E_Table_Activity.class));
                finishAffinity();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                String key= orderModel.getKey();
                orderModel.setStatus("Cancel");
                Order_Ref.child(key).setValue(null);
                Toast.makeText(Current_Order_Activity.this, "Cancel Successfully", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Current_Order_Activity.this,E_Table_Activity.class));
                finishAffinity();
            }
        });
        builder.show();
    }

    public void Edit_Order(View view) {
        Intent a = new Intent(Current_Order_Activity.this,Dashboard.class);
        a.putExtra("table",orderModel.getTable_Number());
        a.putExtra("type","Update");
        a.putExtra("model",orderModel);
        startActivity(a);
    }

    public void Cancel_Order(View view) {
        String key= orderModel.getKey();
        orderModel.setStatus("Cancel");
        Order_Ref.child(key).setValue(null);
        Toast.makeText(Current_Order_Activity.this, "Cancel Successfully", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(Current_Order_Activity.this,E_Table_Activity.class));
        finishAffinity();
    }

    public void Play_Game(View view) {
        startActivity(new Intent(Current_Order_Activity.this,Game_Web_Activity.class)
                .putExtra("link","https://poki.com/"));
    }

    public void Order_Complete(View view) {
/*        String key= orderModel.getKey();
        orderModel.setStatus("Complete");
        Order_Ref.child(key).setValue(orderModel);
        Toast.makeText(Current_Order_Activity.this, "Completed Successfully", Toast.LENGTH_SHORT).show();*/
        startActivity(new Intent(Current_Order_Activity.this,Order_Summary.class)
                .putExtra("model",orderModel));
    }

    @Override
    public void onBackPressed() {
        if (timer!=null){
            timer.cancel();
            timer=null;
        }
    }
}