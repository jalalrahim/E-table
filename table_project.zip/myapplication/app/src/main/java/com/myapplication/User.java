package com.myapplication;

public class User {

    private String Name;
    private String Password;
    private String Email;
    private String Number;
    private String Date;
    private String Gender;

    public User(String name, String password, String email, String number, String date, String gender) {
        Name = name;
        Password = password;
        Email = email;
        Number = number;
        Date = date;
        Gender = gender;
    }

    public String getNumber() {
        return Number;
    }

    public void setNumber(String number) {
        Number = number;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }




    public User() {

    }



    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getEmail() {
        return Email;
    }

    public  void setEmail(String email) {
        Email = email;
    }

}
