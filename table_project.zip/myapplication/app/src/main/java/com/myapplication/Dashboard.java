package com.myapplication;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class Dashboard extends AppCompatActivity{
    TextView date1,time1;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    TextView tv_cat,tv_opt,tv_pro,tv_quantity,tv_title,tv_price;
    DatabaseReference Order_Ref;
    AppCompatButton btn_Submit;
    ImageView btn_plus,btn_minus;
    String table_no="",type="";
    OrderModel orderModel;
    String pr="1";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        table_no=getIntent().getStringExtra("table");
        type=getIntent().getStringExtra("type");
        Order_Ref=FirebaseDatabase.getInstance().getReference("Order").child(FirebaseAuth.getInstance().getCurrentUser().getUid());
        date1=findViewById(R.id.static_spinner4);
        btn_Submit=findViewById(R.id.sign_up);
        btn_plus=findViewById(R.id.btn_plus);
        btn_minus=findViewById(R.id.btn_minus);
        tv_cat=findViewById(R.id.tv_cat);
        tv_opt=findViewById(R.id.tv_opt);
        tv_pro=findViewById(R.id.tv_pro);
        tv_price=findViewById(R.id.tv_price);
        tv_quantity=findViewById(R.id.tv_quantity);
        tv_title=findViewById(R.id.tv_title);
        time1=findViewById(R.id.static_spinner5);
        if (type.equals("Add")){
            tv_title.setText("Create Order");
        }else {
            tv_title.setText("Edit Order");
            orderModel= (OrderModel) getIntent().getSerializableExtra("model");
            table_no=orderModel.getTable_Number();
            Set_Views();
        }
        tv_cat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] items=getApplicationContext().getResources().getStringArray(R.array.category);
                Show_dialog(items,tv_cat);
            }
        });
        tv_pro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s=tv_cat.getText().toString().trim();
                if (!s.equals("")){
                    String[] items=null;
                    if (s.equals("Drinks")){
                        pr="40";
                        tv_price.setText(pr);
                        items=getApplicationContext().getResources().getStringArray(R.array.Drinks);
                    }
                    if (s.equals("Pizza")){
                        pr="500";
                        tv_price.setText(pr);
                        items=getApplicationContext().getResources().getStringArray(R.array.Pizza);
                    }
                    if (s.equals("Burger")){
                        pr="200";
                        tv_price.setText(pr);
                        items=getApplicationContext().getResources().getStringArray(R.array.Burger);
                    }
                    Show_dialog(items,tv_pro);
                }else {
                    Toast.makeText(Dashboard.this, "First Select Category", Toast.LENGTH_SHORT).show();
                }
            }
        });
        tv_opt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] items=getApplicationContext().getResources().getStringArray(R.array.option);
                Show_dialog(items,tv_opt);
            }
        });

        time1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar c = Calendar.getInstance();
                int  mHour = c.get(Calendar.HOUR_OF_DAY);
                int  mMinute = c.get(Calendar.MINUTE);

                // Launch Time Picker Dialog
                TimePickerDialog timePickerDialog = new TimePickerDialog(Dashboard.this,
                        new TimePickerDialog.OnTimeSetListener() {

                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {

                                time1.setText(hourOfDay + ":" + minute+":00");
                            }
                        }, mHour, mMinute, false);
                timePickerDialog.show();
            }
        });
        //for date
        date1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal=Calendar.getInstance();
                int year=cal.get(Calendar.YEAR);
                int month=cal.get(Calendar.MONTH);
                int day=cal.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dialog= new DatePickerDialog(Dashboard.this,android.R.style.Theme_Holo_Dialog_MinWidth,
                        mDateSetListener,year,month,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });
        mDateSetListener= new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;
                Log.d(TAG, "onDateSet: date:"+month+"/"+dayOfMonth+"/"+year);
                String date = month + "/" + dayOfMonth + "/" + year;
                date1.setText(date);
            }
        };
        btn_Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String cat=tv_cat.getText().toString().trim();
                String pro=tv_pro.getText().toString().trim();
                String opt=tv_opt.getText().toString().trim();
                String date=date1.getText().toString().trim();
                String time=time1.getText().toString().trim();
                String quan=tv_quantity.getText().toString().trim();
                String price=tv_price.getText().toString().trim();
                if (cat.equals("")){
                    tv_cat.setError("Select Category");
                    return;
                }
                if (pro.equals("")){
                    tv_pro.setError("Select Product");
                    return;
                }
                if (opt.equals("")){
                    tv_opt.setError("Select Option");
                    return;
                }
                if (date.equals("")){
                    date1.setError("Select Date");
                    return;
                }
                if (time.equals("")){
                    time1.setError("Select Time");
                    return;
                }
                if (quan.equals("")){
                    tv_quantity.setError("Add Quantity");
                    return;
                }
                if (price.equals("")){
                    tv_price.setError("Add Price");
                    return;
                }
                if (type.equals("Add")){
                    String key=Order_Ref.push().getKey();
                    OrderModel orderModel=new OrderModel(cat,pro,opt,date,time,quan,price,key,
                            FirebaseAuth.getInstance().getCurrentUser().getUid(),table_no,"Ongoing");
                    Order_Ref.child(key).setValue(orderModel);
                    Toast.makeText(Dashboard.this, "Submit Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Dashboard.this,Current_Order_Activity.class)
                            .putExtra("model",orderModel));
                    finish();
                }else {
                    String key= orderModel.getKey();
                    OrderModel orderModel=new OrderModel(cat,pro,opt,date,time,quan,price,key,
                            FirebaseAuth.getInstance().getCurrentUser().getUid(),table_no,"Ongoing");
                    Order_Ref.child(key).setValue(orderModel);
                    Toast.makeText(Dashboard.this, "Submit Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Dashboard.this,Current_Order_Activity.class)
                            .putExtra("model",orderModel));
                    finish();
                }
            }
        });
        btn_minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ss=tv_quantity.getText().toString().trim();
                int c=Integer.parseInt(ss);
                if (c>=1){
                    ++c;
                    int t=Integer.parseInt(pr)*c;
                    tv_price.setText(""+t);
                    tv_quantity.setText(""+c);
                }else {
                    int t=Integer.parseInt(pr)*c;
                    tv_price.setText(""+t);
                }
            }
        });
        btn_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ss=tv_quantity.getText().toString().trim();
                int c=Integer.parseInt(ss);
                if (c>0&&c!=1){
                    --c;
                    int t=Integer.parseInt(pr)*c;
                    tv_price.setText(""+t);
                    tv_quantity.setText(""+c);
                }else {
                    int t=Integer.parseInt(pr)*c;
                    tv_price.setText(""+t);
                }
            }
        });

  }

    private void Set_Views() {
        tv_cat.setText(orderModel.getCategory());
        tv_pro.setText(orderModel.getProduct());
        tv_opt.setText(orderModel.getOption());
        time1.setText(orderModel.getTime());
        date1.setText(orderModel.getDate());
        tv_quantity.setText(orderModel.getQuantity());
        tv_price.setText(orderModel.getPrice());

    }

    private void Show_dialog(String[] items, TextView tv_cat) {
        AlertDialog.Builder builder=new AlertDialog.Builder(Dashboard.this);
        builder.setTitle("Select Category");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                tv_cat.setText(items[i]);
                tv_cat.setError(null);
            }
        });
        builder.show();
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(),E_Table_Activity.class));

    }
}