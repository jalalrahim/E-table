package com.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class login extends AppCompatActivity {
    TextView tvSignIn, tvForgot;
    FirebaseAuth firebaseAuth;
    FirebaseUser user;

    EditText editPhone, editPassword;
    Button btnLogIn;

    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        tvSignIn = findViewById(R.id.tvSignIn);
        tvForgot = findViewById(R.id.tvForgot);
        editPhone = findViewById(R.id.email1);
        editPassword = findViewById(R.id.password1);
        btnLogIn = findViewById(R.id.log_in);
        progressBar=findViewById(R.id.progressBar);
        firebaseAuth=FirebaseAuth.getInstance();
        btnLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String email = editPhone.getText().toString();
                String password = editPassword.getText().toString();
                if(email.length()==0){
                    editPhone.setError("It is Empty");
                    editPhone.requestFocus();
                    return;
                }
                if(password.length()==0) {
                    editPassword.setError("It is Empty");
                    editPassword.requestFocus();
                    return;
                }
                progressBar.setVisibility(View.VISIBLE);
                firebaseAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            startActivity(new Intent(login.this, E_Table_Activity.class));
                            progressBar.setVisibility(View.GONE);

                        } else {
                            Toast.makeText(login.this, "Error!!!" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }






                });
            }
        });


        tvSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(login.this, MainActivity.class);
                startActivity(i);
            }
        });

    }
}