package com.myapplication;

import java.io.Serializable;

public class OrderModel implements Serializable {
    String Category,Product,Option,Date,Time,Quantity,Price,key,uid,table_Number,Status;

    public OrderModel(String category, String product, String option, String date, String time, String quantity, String price, String key, String uid) {
        Category = category;
        Product = product;
        Option = option;
        Date = date;
        Time = time;
        Quantity = quantity;
        Price = price;
        this.key = key;
        this.uid = uid;
    }

    public OrderModel() {
    }

    public OrderModel(String category, String product, String option, String date, String time, String quantity, String price, String key, String uid, String table_Number, String status) {
        Category = category;
        Product = product;
        Option = option;
        Date = date;
        Time = time;
        Quantity = quantity;
        Price = price;
        this.key = key;
        this.uid = uid;
        this.table_Number = table_Number;
        Status = status;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getTable_Number() {
        return table_Number;
    }

    public void setTable_Number(String table_Number) {
        this.table_Number = table_Number;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public String getProduct() {
        return Product;
    }

    public void setProduct(String product) {
        Product = product;
    }

    public String getOption() {
        return Option;
    }

    public void setOption(String option) {
        Option = option;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getQuantity() {
        return Quantity;
    }

    public void setQuantity(String quantity) {
        Quantity = quantity;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
