package com.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.myapplication.OCR.MainActivity;

import java.util.ArrayList;

public class E_Table_Activity extends AppCompatActivity {

    ArrayList<String> table_list=new ArrayList<>();
    TextView tv_tavle;
    DatabaseReference Order_Ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_etable);
        table_list.add("Table No.1");table_list.add("Table No.2");table_list.add("Table No.3");
        table_list.add("Table No.4");table_list.add("Table No.5");table_list.add("Table No.6");
        Order_Ref= FirebaseDatabase.getInstance().getReference("Order").child(FirebaseAuth.getInstance().getCurrentUser().getUid());

        Order_Ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    for (DataSnapshot dataSnapshot:snapshot.getChildren()){
                        OrderModel orderModel=dataSnapshot.getValue(OrderModel.class);
                        if (orderModel.getStatus().equals("Ongoing")){
                            startActivity(new Intent(E_Table_Activity.this,Current_Order_Activity.class)
                                    .putExtra("model",orderModel));
                            finish();
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        tv_tavle=findViewById(R.id.tv_tavle);table_list.toArray(new String[0]);
        tv_tavle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] arr= getResources().getStringArray(R.array.table);
                Show_dialog(arr,tv_tavle);
            }
        });
    }
    private void Show_dialog(String[] items, TextView tv_cat) {
        AlertDialog.Builder builder=new AlertDialog.Builder(E_Table_Activity.this);
        builder.setTitle("Select Table No.");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                tv_cat.setText(items[i]);
                tv_cat.setError(null);
            }
        });
        builder.show();
    }

    public void Place_order_fun(View view) {
        String table=tv_tavle.getText().toString().trim();
        if (table.equals("")){
            Toast.makeText(this, "Please Select Table", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent a = new Intent(E_Table_Activity.this,Dashboard.class);
        a.putExtra("table",table);
        a.putExtra("type","Add");
        startActivity(a);
        finish();
    }

    public void LogOut(View view) {
        FirebaseAuth.getInstance().signOut();
        Toast.makeText(this, "LogOut Successfully", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(getApplicationContext(), login.class));
        finishAffinity();
    }

    public void See_Orde(View view) {

    }
}