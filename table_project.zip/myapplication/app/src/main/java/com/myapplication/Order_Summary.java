package com.myapplication;

import static android.content.ContentValues.TAG;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class Order_Summary extends AppCompatActivity{
    TextView date1,time1;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    TextView tv_cat,tv_opt,tv_pro;
    DatabaseReference Order_Ref;
    AppCompatButton btn_Submit;
    TextView tv_price,tv_quantity;
    OrderModel orderModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);
        Order_Ref=FirebaseDatabase.getInstance().getReference("Order").child(FirebaseAuth.getInstance().getCurrentUser().getUid());
        orderModel= (OrderModel) getIntent().getSerializableExtra("model");
        date1=findViewById(R.id.static_spinner4);
        btn_Submit=findViewById(R.id.sign_up);
        tv_cat=findViewById(R.id.tv_cat);
        tv_opt=findViewById(R.id.tv_opt);
        tv_pro=findViewById(R.id.tv_pro);
        tv_price=findViewById(R.id.tv_price);
        tv_quantity=findViewById(R.id.tv_quantity);
        time1=findViewById(R.id.static_spinner5);
        tv_cat.setText(orderModel.getCategory());
        tv_pro.setText(orderModel.getProduct());
        tv_opt.setText(orderModel.getOption());
        date1.setText(orderModel.getDate());
        time1.setText(orderModel.getTime());
        tv_quantity.setText(orderModel.getQuantity());
        tv_price.setText(orderModel.getPrice());
        //for date
  }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(Order_Summary.this,Dashboard.class));
    }
}